tz.ptvo_set_display_value = {
    key: ['set_display_value'],
    convertSet: async (entity, key, value, meta) => {
        const write_value = parseFloat(value);
        const payload = {
            0x55: {
                value: write_value,
                type: 0x39
            }
        };
        await entity.write('genAnalogInput', payload);
    },
    convertGet: async (entity, key, meta) => {
        return;
    },
};

/* Convert a string to a unicode byte array
 * @param {string} str
 * @return {Array} of bytes
 */
function strToUtf8Bytes(str) {
  const utf8 = [];
  for (let ii = 0; ii < str.length; ii++) {
    let charCode = str.charCodeAt(ii);
    if (charCode < 0x80) {
      utf8.push(charCode);
    }
    else if (charCode < 0x800) {
      utf8.push(0xc0 | (charCode >> 6), 0x80 | (charCode & 0x3f));
    } else if (charCode < 0xd800 || charCode >= 0xe000) {
      utf8.push(0xe0 | (charCode >> 12), 0x80 | ((charCode >> 6) & 0x3f), 0x80 | (charCode & 0x3f));
    } else {
      ii++;
      // Surrogate pair:
      // UTF-16 encodes 0x10000-0x10FFFF by subtracting 0x10000 and
      // splitting the 20 bits of 0x0-0xFFFFF into two halves
      charCode = 0x10000 + (((charCode & 0x3ff) << 10) | (str.charCodeAt(ii) & 0x3ff));
      utf8.push(
        0xf0 | (charCode >> 18),
        0x80 | ((charCode >> 12) & 0x3f),
        0x80 | ((charCode >> 6) & 0x3f),
        0x80 | (charCode & 0x3f),
      );
    }
  }
  return utf8;
}

tz.ptvo_set_display_text = {
    key: ['set_display_text'],
    convertSet: async (entity, key, value, meta) => {
        // attr: Description, data type: String (0x42)
        // Properly handle string with non-latin characters
        const str = value.toString();
        const a = strToUtf8Bytes(str);
        a.unshift(a.length);
        const payload = {
            0x1C: {
                value: a,
                type: 0x42
            }
        };
        await entity.write('genAnalogInput', payload);
    },
    convertGet: async (entity, key, meta) => {
        return;
    },
};
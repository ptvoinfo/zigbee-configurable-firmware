tz.ptvo_acs712_command = {
    key: ['command'],
    convertSet: async (entity, key, value, meta) => {
        if (!value) {
            return;
        }
        // attr: presentValue, data type: single precision float
        let write_value = 0;
        switch (value) {
        case 'ZERO':
            write_value = 0;
            break;
        default:
            return;
        }
        const payload = {
            0x55: {
                value: write_value,
                type: 0x39
            }
        };
        await entity.write('genAnalogInput', payload);
    },
    convertGet: async (entity, key, meta) => {
        return;
    },
};

CAUTION: DO NOT USE HEX FILES FROM THIS FOLDER DIRECTLY, WITHOUT A CONFIGURATION

How to use
=========================

1. Launch the "FirmwareConfig.exe" utility.
2. Configure the firmware for your chip, board, and needs. Optionally, you may click the "File - Read settings from a file" menu item and load settings from an existing preset in the "Presets" folder.
3. Click the "Save" button and get the final HEX file. Note: some features may require the Premium version of this firmware.
